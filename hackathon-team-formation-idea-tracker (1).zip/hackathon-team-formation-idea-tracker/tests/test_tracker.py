import json, os, sys, tempfile, threading, unittest, urllib.request
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import hackathon_tracker as ht
import webapp


class Base(unittest.TestCase):
    def setUp(self):
        fd, self.path = tempfile.mkstemp(suffix=".db"); os.close(fd)
        ht.DB_PATH = self.path; ht.init_db()
        with ht.get_conn() as c:
            for n, e, s in [("Asha", "a@x", "python,ml"), ("Ravi", "r@x", "design,react"),
                            ("Meera", "m@x", "python"), ("Kiran", "k@x", "")]:
                c.execute("INSERT INTO participants (name,email,skills,created_at) VALUES (?,?,?,?)", (n, e, s, ht.now()))
            c.execute("INSERT INTO ideas (title,needed_skills,created_at) VALUES ('Recycler','design,python',?)", (ht.now(),))
            c.execute("INSERT INTO teams (name,idea_id,max_size,created_at) VALUES ('Green',1,2,?)", (ht.now(),))

    def tearDown(self):
        os.remove(self.path)


class CoreTests(Base):
    def test_rank_candidates(self):
        with ht.get_conn() as c:
            scored = ht.rank_candidates(c, 1)[4]
        self.assertEqual([p["id"] for _, p, _ in scored], [1, 2, 3])  # Kiran has no skills

    def test_auto_assign_fills_team(self):
        with ht.get_conn() as c:
            placed = ht.auto_assign(c)
        self.assertEqual([p for _, p, _ in placed], ["Asha", "Ravi"])
        with ht.get_conn() as c:
            self.assertEqual(ht.compute_stats(c)["assigned"], 2)

    def test_dry_run_saves_nothing(self):
        with ht.get_conn() as c:
            self.assertEqual(len(ht.auto_assign(c, dry_run=True)), 2)
        with ht.get_conn() as c:
            self.assertEqual(ht.compute_stats(c)["assigned"], 0)

    def test_export_and_stats(self):
        with ht.get_conn() as c:
            self.assertEqual(len(ht.export_data(c)["participants"]), 4)
            self.assertEqual(ht.compute_stats(c)["top_skills"][0], ("python", 2))


class WebTests(Base):
    def test_api(self):
        srv = webapp.make_server("127.0.0.1", 0)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        base = "http://127.0.0.1:%d" % srv.server_address[1]
        try:
            req = urllib.request.Request(base + "/api/vote", headers={"Content-Type": "application/json"},
                                         data=json.dumps({"idea": 1, "participant": 1}).encode())
            self.assertTrue(json.load(urllib.request.urlopen(req))["ok"])
            self.assertEqual(json.load(urllib.request.urlopen(base + "/api/state"))["ideas"][0]["votes"], 1)
            self.assertIn(b"Hackathon", urllib.request.urlopen(base + "/").read())
        finally:
            srv.shutdown(); srv.server_close()


if __name__ == "__main__":
    unittest.main()
