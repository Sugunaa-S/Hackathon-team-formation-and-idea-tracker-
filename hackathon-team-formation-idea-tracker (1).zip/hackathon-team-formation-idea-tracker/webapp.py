"""Web interface: a tiny JSON API plus one HTML page, using only the standard library."""
import json
import os
import sqlite3
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

import hackathon_tracker as ht

HERE = os.path.dirname(os.path.abspath(__file__))


class ApiError(Exception):
    pass


def need(body, key):
    v = body.get(key)
    if v in (None, ""):
        raise ApiError(f"'{key}' is required")
    return v


def state():
    with ht.get_conn() as c:
        participants = [dict(r) for r in c.execute(
            "SELECT p.id, p.name, p.email, p.skills, t.name AS team FROM participants p "
            "LEFT JOIN team_members tm ON tm.participant_id = p.id "
            "LEFT JOIN teams t ON t.id = tm.team_id ORDER BY p.id")]
        ideas = [dict(r) for r in c.execute(
            "SELECT i.id, i.title, i.description, i.status, i.needed_skills, "
            "COALESCE(p.name, '-') AS owner, "
            "(SELECT COUNT(*) FROM votes v WHERE v.idea_id = i.id) AS votes "
            "FROM ideas i LEFT JOIN participants p ON p.id = i.owner_id "
            "ORDER BY votes DESC, i.id")]
        teams = []
        for t in c.execute(
                "SELECT t.id, t.name, t.max_size, COALESCE(i.title, '-') AS idea "
                "FROM teams t LEFT JOIN ideas i ON i.id = t.idea_id ORDER BY t.id").fetchall():
            d = dict(t)
            d["members"] = [dict(m) for m in c.execute(
                "SELECT p.id, p.name FROM team_members tm "
                "JOIN participants p ON p.id = tm.participant_id WHERE tm.team_id = ?", (t["id"],))]
            teams.append(d)
        stats = ht.compute_stats(c)
    return {"participants": participants, "ideas": ideas, "teams": teams,
            "stats": stats, "statuses": ht.IDEA_STATUSES}


def a_participant(c, b):
    c.execute("INSERT INTO participants (name, email, skills, created_at) VALUES (?,?,?,?)",
              (need(b, "name").strip(), need(b, "email").strip().lower(),
               ht.normalize_skills(b.get("skills", "")), ht.now()))


def a_idea(c, b):
    c.execute("INSERT INTO ideas (title, description, owner_id, needed_skills, created_at) "
              "VALUES (?,?,?,?,?)",
              (need(b, "title").strip(), (b.get("description") or "").strip(),
               b.get("owner") or None, ht.normalize_skills(b.get("needs", "")), ht.now()))


def a_status(c, b):
    if need(b, "status") not in ht.IDEA_STATUSES:
        raise ApiError("Invalid status")
    ht.require_row(c, "ideas", need(b, "idea"), "Idea")
    c.execute("UPDATE ideas SET status = ? WHERE id = ?", (b["status"], b["idea"]))


def a_vote(c, b):
    try:
        c.execute("INSERT INTO votes (idea_id, participant_id, created_at) VALUES (?,?,?)",
                  (need(b, "idea"), need(b, "participant"), ht.now()))
    except sqlite3.IntegrityError:
        raise ApiError("Already voted for that idea, or unknown participant/idea.")


def a_team(c, b):
    try:
        c.execute("INSERT INTO teams (name, idea_id, max_size, created_at) VALUES (?,?,?,?)",
                  (need(b, "name").strip(), b.get("idea") or None,
                   int(b.get("max_size") or ht.DEFAULT_MAX_TEAM_SIZE), ht.now()))
    except sqlite3.IntegrityError:
        raise ApiError("Team name already exists, or idea not found.")


def a_join(c, b):
    team = ht.require_row(c, "teams", need(b, "team"), "Team")
    if ht.team_member_count(c, team["id"]) >= team["max_size"]:
        raise ApiError(f"Team '{team['name']}' is full.")
    try:
        c.execute("INSERT INTO team_members (team_id, participant_id, joined_at) VALUES (?,?,?)",
                  (team["id"], need(b, "participant"), ht.now()))
    except sqlite3.IntegrityError:
        raise ApiError("Participant is already on a team, or does not exist.")


def a_auto(c, b):
    placed = ht.auto_assign(c, bool(b.get("dry_run")))
    return {"placed": [{"team": t, "participant": p, "score": s} for t, p, s in placed]}


ACTIONS = {"/api/participants": a_participant, "/api/ideas": a_idea, "/api/status": a_status,
           "/api/vote": a_vote, "/api/teams": a_team, "/api/join": a_join,
           "/api/auto-teams": a_auto}


class Handler(BaseHTTPRequestHandler):
    def _send(self, code, payload, ctype="application/json"):
        data = payload if isinstance(payload, bytes) else json.dumps(payload).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        path = urlparse(self.path).path
        try:
            if path == "/":
                with open(os.path.join(HERE, "index.html"), "rb") as f:
                    self._send(200, f.read(), "text/html; charset=utf-8")
            elif path == "/api/state":
                self._send(200, state())
            elif path == "/api/export.json":
                with ht.get_conn() as c:
                    self._send(200, ht.export_data(c))
            elif path.startswith("/api/suggest/"):
                with ht.get_conn() as c:
                    _, needed, have, missing, scored = ht.rank_candidates(c, int(path.rsplit("/", 1)[1]))
                self._send(200, {"missing": sorted(missing), "suggestions": [
                    {"id": p["id"], "name": p["name"], "score": s, "fills": sorted(f)}
                    for s, p, f in scored[:5]]})
            else:
                self._send(404, {"error": "Not found"})
        except SystemExit:
            self._send(404, {"error": "Record not found"})
        except ValueError:
            self._send(400, {"error": "Invalid id"})

    def do_POST(self):
        fn = ACTIONS.get(urlparse(self.path).path)
        if not fn:
            return self._send(404, {"error": "Not found"})
        try:
            raw = self.rfile.read(int(self.headers.get("Content-Length") or 0)) or b"{}"
            with ht.get_conn() as c:
                result = fn(c, json.loads(raw)) or {}
            self._send(200, {"ok": True, **result})
        except ApiError as e:
            self._send(400, {"error": str(e)})
        except SystemExit:
            self._send(400, {"error": "Referenced record not found."})
        except sqlite3.IntegrityError:
            self._send(400, {"error": "Duplicate entry, or a referenced record does not exist."})
        except (ValueError, TypeError):
            self._send(400, {"error": "Invalid input."})

    def log_message(self, *args):
        pass


def make_server(host="127.0.0.1", port=8000):
    ht.init_db()
    return ThreadingHTTPServer((host, port), Handler)


def serve(host="127.0.0.1", port=8000):
    srv = make_server(host, port)
    print(f"Hackathon Hub running at http://{host}:{srv.server_address[1]}  (Ctrl+C to stop)")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
